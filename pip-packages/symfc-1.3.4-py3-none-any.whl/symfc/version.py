"""Version number of the package."""

__version__ = "1.3.4"
