from .compilers.C import zos

zOSCCompiler = zos.Compiler
