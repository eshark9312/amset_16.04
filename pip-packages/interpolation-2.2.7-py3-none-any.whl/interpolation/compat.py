from packaging.version import parse

from numba import __version__

overload_options = {"strict": False}

from numba.core.types import Array, Float, Integer
from numba.core.types import Tuple, UniTuple
