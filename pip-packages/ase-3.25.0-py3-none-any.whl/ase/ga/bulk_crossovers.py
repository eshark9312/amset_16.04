# fmt: off

raise ImportError(
    'The ase.ga.bulk_crossovers module has been deprecated. '
    'The same functionality is now provided by the '
    'ase.ga.cutandsplicepairing module. Please consult its documentation '
    'to verify how to e.g. initialize a CutAndSplicePairing object.')
