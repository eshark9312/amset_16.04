from ase.collections.collection import Collection

g2 = Collection('g2')
s22 = Collection('s22')
dcdft = Collection('dcdft')
