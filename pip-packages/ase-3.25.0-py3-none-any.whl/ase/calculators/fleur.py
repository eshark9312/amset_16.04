# fmt: off

def FLEUR(*args, **kwargs):
    raise RuntimeError(
        'Please refer to the python package ase-fleur for '
        'ASE support for modern FLEUR versions.  See: '
        'https://github.com/JuDFTteam/ase-fleur.')
