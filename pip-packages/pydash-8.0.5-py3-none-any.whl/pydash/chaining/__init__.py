from .chaining import _Dash, chain, tap


__all__ = (
    "_Dash",
    "chain",
    "tap",
)
