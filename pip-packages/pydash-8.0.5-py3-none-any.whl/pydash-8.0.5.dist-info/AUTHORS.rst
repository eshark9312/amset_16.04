Authors
=======


Lead
----

- Derrick Gilland, dgilland@gmail.com, `dgilland@github <https://github.com/dgilland>`_


Contributors
------------

- Nathan Cahill, nathan@nathancahill.com, `nathancahill@github <https://github.com/nathancahill>`_
- Klaus Sevensleeper, k7sleeper@gmail.com, `k7sleeper@github <https://github.com/k7sleeper>`_
- Bharadwaj Yarlagadda, yarlagaddabharadwaj@gmail.com, `bharadwajyarlagadda@github <https://github.com/bharadwajyarlagadda>`_
- Michael James, `urbnjamesmi1@github <https://github.com/urbnjamesmi1>`_
- Tim Griesser, tgriesser@gmail.com, `tgriesser@github <https://github.com/tgriesser>`_
- Shaun Patterson, `shaunpatterson@github <https://github.com/shaunpatterson>`_
- Brian Beck, `beck3905@github <https://github.com/beck3905>`_
- Frank Epperlein, `efenka@github <https://github.com/efenka>`_
- Joshua Wilson, `jwilson8767@github <https://github.com/jwilson8767>`_
- Eli Jose, `elijose55@github <https://github.com/elijose55>`_
- Gonzalo Naveira, `gonzalonaveira@github <https://github.com/gonzalonaveira>`_
- Wenbo Zhao, zhaowb@gmail.com, `zhaowb@github <https://github.com/zhaowb>`_
- Mervyn Lee, `mervynlee94@github <https://github.com/mervynlee94>`_
- Weineel Lee, `weineel@github <https://github.com/weineel>`_
- bl4ckst0ne@github `bl4ckst0ne@github <https://github.com/bl4ckst0ne>`_
- Thomas `DeviousStoat@github <https://github.com/DeviousStoat>`_
