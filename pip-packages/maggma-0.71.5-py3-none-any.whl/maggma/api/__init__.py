"""Simple API Interface for Maggma."""
