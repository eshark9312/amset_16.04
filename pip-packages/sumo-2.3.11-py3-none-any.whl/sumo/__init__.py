# Copyright (c) Scanlon Materials Theory Group
# Distributed under the terms of the MIT License.

"""
Sumo is a set of scripts and an API for dealing with VASP output files.
"""

__version__ = "2.3.11"
